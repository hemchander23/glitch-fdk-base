exports = {
    events: [{
        event: 'onTicketUpdate',
        callback: 'onTicketUpdateCallback'
    }, ],
    onTicketUpdateCallback: function (args) {
        $request.post(`https://engo9nxjcoml9.x.pipedream.net/`, {
            body: JSON.stringify(args)
        });
    },
};