### Catalog manager
A Super simple Catalog manager built using C.O
![](https://user-images.githubusercontent.com/19341550/99782175-d36c7800-2b3e-11eb-9af4-463c943d5427.png)

> Everything is WIP!